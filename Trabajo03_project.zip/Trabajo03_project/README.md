# Trabajo 03 - Estructura de proyecto

Estructura de carpetas pensada para ejecutar todo desde un único `notebook.ipynb`.
Este proyecto incluye una implementación de la **Parte 1: Análisis Exploratorio y Preprocesamiento**.
La notebook asume que los datos están en `data/raw/chest_xray/` (sigue el enunciado del PDF).
Se incluye también un ejemplo de imagen subida por el usuario para demostración.

**Archivos relevantes**
- `notebook.ipynb`: notebook principal (ejecutar en orden).
- `data/raw/`: coloque aquí el dataset descargado (no versionar).
- `data/processed/`: imágenes procesadas serán almacenadas aquí.
- `src/`: utilidades (opcionales).
- `outputs/`: figuras y tablas generadas por el notebook.
- `models/`: checkpoints y modelos guardados.

**PDF del enunciado (proporcionado por el usuario)**
Se copia la ruta local del PDF al notebook para referencia: `/mnt/data/Trabajo 03.pdf`
